package com.example.basic_1_textview

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Html
import android.widget.TextView
import com.example.basic_1_textview.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    var nCount : Int = 0   // 클래스의 멤버변수는 반드시 초기화 되어야 한다!

    val binding by lazy { ActivityMainBinding.inflate(layoutInflater) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        binding.txtNormal.setOnClickListener {
            binding.txtNormal.apply {
                setBackgroundColor(Color.RED)
                text = "Clicked!! ${nCount++}"
                setTextColor(Color.WHITE)
                setTextSize(28.0F)  // 대표적인 컬러 상수처리 가능
            }
        }
        binding.txtHTML.setOnClickListener {
            val htmlText = it as TextView    // binding.txtHTML
            htmlText.text = Html.fromHtml("<h1>Hi</h1>HTML<p style=\"color:red;\">Red</p>")


        }

    }
}